/**********************************************************************

   File          : cse543-lattice.h

   Description   : Lattice defines and functions.

***********************************************************************/
/**********************************************************************
Copyright (c) 2012 The Pennsylvania State University
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of The Pennsylvania State University nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
***********************************************************************/

/* Include Files */

/* Defines */
#define E_LEVEL 1
#define E_MAP   2
#define E_TRANS 4


/* Policy Types */
typedef struct level_t {
	char *name;
	int len;
} level;


typedef struct map_t {
	char *name;
	int len;
	level *l;
} map;


typedef struct trans_t {
	level *subj;
  	level *obj;
	level *new;
	int op;
} trans;


/* Globals */
extern list lattice;
extern list label_mapping;
extern list trans_mapping;


/* Functional Prototypes */

/**********************************************************************

    Function    : addLattice
    Description : Add levels - add from low to high levels
    Inputs      : fh - output file pointer
                  low - name of lower level
                  high - name of higher level
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

extern int addLattice( FILE *fh, char *low, char *high );

/**********************************************************************

    Function    : addLabelPolicy
    Description : Add mapping from name to level
    Inputs      : fh - output file pointer
                  name - name (prefix) of objects at level
                  level - name of level
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

extern int addLabelPolicy( FILE *fh, char *name, char *level );

/**********************************************************************

    Function    : addTransPolicy
    Description : Add mapping from name to level
    Inputs      : fh - output file pointer
                  subj_level - level of subject of op
                  obj_level - level of object of op
                  new_level - resultant level of subj or obj (op-dependent)
                  op - operation (rwx)
                  ttype - transition type (process or file)
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

extern int addTransPolicy( FILE *fh, char *subj_level, char *obj_level, char* new_level, 
			   int op, int ttype );

/**********************************************************************

    Function    : matchName
    Description : Find if node name matches supplied name
    Inputs      : elt - element to check 
                  obj - object to match on
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

extern int matchLevelName( elt *e, void *obj );
extern int matchMapName( elt *e, void *obj );
extern int matchLevel( elt *e, void *obj );
extern int matchTrans( elt *e, void *obj );
