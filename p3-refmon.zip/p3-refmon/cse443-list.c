/**********************************************************************

   File          : cse443-list.c

   Description   : This file contains the list processing code

***********************************************************************/

/**********************************************************************
Copyright (c) 2012 The Pennsylvania State University
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of The Pennsylvania State University nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
***********************************************************************/

/* Include Files */
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/stat.h>

/* Project Include Files */
#include "cse443-util.h"
#include "cse443-list.h"

/* Globals */

/* Functional Prototypes */  

/**********************************************************************

    Function    : init
    Description : initialize list
    Inputs      : list - list object
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

int init( list *l )
{
	l->head = NULL;

	return 0;
}


/**********************************************************************

    Function    : insert
    Description : Insert element in list after (optional) elt
    Inputs      : list - list object
                  new - new element to insert
                  after - optional element to insert after (if null, place at head)
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

int insert( list *l, elt *new, elt *after )
{
	elt *tmp;

	if ( !after ) {
		tmp = l->head;
		l->head = new;
		new->next = tmp;
	}
	else {
		tmp = after->next;
		after->next = new;
		new->next = tmp;
	}
	
	return 0;
}

/**********************************************************************

    Function    : get
    Description : get element that matches 
    Inputs      : list - list object
                  obj - object to compare
                  cmp - comparison function 
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

elt *get( list *l, void *obj, int(*cmp)(elt *e, void *obj))
{
	elt *node = l->head;
	
	while( node != NULL )
	{
		if ( cmp( node, obj ) ) {
			return node;
		}
		node = node->next;
	}
	return NULL;
}



/**********************************************************************

    Function    : pos
    Description : retrieve position in list of elt
    Inputs      : list - list object
                  obj - object to match from elts in list
                  cmp - function for comparison
    Outputs     : 0 if successfully completed, -1 if failure

***********************************************************************/

int pos( list *l, void *obj, int(*cmp)(elt *e, void *obj))
{
	elt *node = l->head;
	int ct = 0;
	
	while( node != NULL )
	{
		if ( cmp( node, obj ) ) {
			return ct;
		}
		node = node->next;
		ct++;
	}
	return -1;
}



