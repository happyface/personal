#ifndef PLAYROOM_H
#define PLAYROOM_H

#include <pthread.h>

struct pet_counter {
	// Number currently in the room
	int n;
	// Number currently waiting outside
	int wait;

	// Number of useless wakeups
	int wakeup;
	// Number of successful entries
	int total;

	pthread_cond_t condit;
};

struct playroom {
	pthread_mutex_t lock;

	// Animal counters
	struct pet_counter cats, dogs, birds, mice, wolves;

	// Flag that room is shutting down
	int ending;
};

int playroom_init(struct playroom *room);
void playroom_destroy(struct playroom *room);

void bird_enter(struct playroom *room);
void bird_exit(struct playroom *room);

void cat_enter(struct playroom *room);
void cat_exit(struct playroom *room);

void dog_enter(struct playroom *room);
void dog_exit(struct playroom *room);

void mouse_enter(struct playroom *room);
void mouse_exit(struct playroom *room);

void wolf_enter(struct playroom *room);
void wolf_exit(struct playroom *room);

void playroom_print(struct playroom *room);
void playroom_visual(struct playroom *room);

#endif
