//  Erica Hollis
// 3/17/11
// Project 2
// CmpSce 473
//
// This project follows certain rules about which animals are allowed to be
// in a playroom with which other kinds.  The project uses mutual exlusion
// and conditions to implement this.  Whenever an animal wants to enter but
// can't, it waits for the conditional signal. Whenever the last animal of a certain kind
// leaves the playroom, three different animal groups are checked to see if they are
// allowed to enter.  The first is wolves because they can only go in one at a time. 
// The next is cats because they can only be in by themselves.
// Lastly, either dogs and birds or mice and birds
// can go in based on whether more dogs or mice are waiting.
// Whenever an animal is signaled to go in, if there are others waiting
// a broadcast signal is sent out to the rest of their kind.
// Except in the case of wolves, and if there are any waiting they
// will eventually get in by the end.
  

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include "params.h"

#include "playroom.h"

// Initialization and destruction functions
int playroom_init(struct playroom *room)
{
	int rv;

	// Zero everything by default
	memset(room, 0, sizeof *room);

	rv = pthread_mutex_init(&room->lock, NULL);
	if (rv)
		return rv;

	rv = pthread_cond_init(&room->birds.condit, NULL);
	if(rv)
		return rv;

	rv = pthread_cond_init(&room->cats.condit, NULL);
	if(rv)
		return rv;

	rv = pthread_cond_init(&room->dogs.condit, NULL);
	if(rv)
		return rv;

	rv = pthread_cond_init(&room->mice.condit, NULL);
	if(rv)
		return rv;

	rv = pthread_cond_init(&room->wolves.condit, NULL);
	if(rv)
		return rv;

	return 0;
}

void playroom_destroy(struct playroom *room)
{
	while (pthread_mutex_destroy(&room->lock) == EBUSY);
	pthread_mutex_destroy(&room->lock);
}

int cat_can_enter(struct playroom *room)
{
	if(room->birds.n == 0 && room->dogs.n == 0 && room->mice.n == 0 && room->wolves.n && 0)
	  return 1;
	else
	  return 0;
}

int wolf_can_enter(struct playroom *room)
{
	if(room->birds.n == 0 && room->cats.n == 0 && room->dogs.n == 0 && room->mice.n == 0)
	  return 1;
	else
	  return 0;
}

void rest_may_enter(struct playroom *room)
{
	if(room->dogs.wait > room->mice.wait)
	{
	   pthread_cond_signal(&room->birds.condit);
	   pthread_cond_signal(&room->dogs.condit);
	}
	else
	{
	   pthread_cond_signal(&room->birds.condit);
	   pthread_cond_signal(&room->mice.condit);
	}
}
	

// Entry/exit functions
void bird_enter(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);	
	while(room->cats.n > 0 || room->wolves.n > 0)
	{	
	  room->birds.wait++;
	  pthread_cond_wait(&room->birds.condit, &room->lock);
	  room->birds.wait--;
	}
	if(room->birds.wait > 0)
	{
	  room->birds.wakeup += room->birds.wait;
	  pthread_cond_broadcast(&room->birds.condit);
	}
	room->birds.n++;
	room->birds.total++;
	pthread_mutex_unlock(&room->lock);
}

void bird_exit(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);
	room->birds.n--;
	if(room->birds.n == 0)
	{
	  if((room->wolves.wait > 0) && (wolf_can_enter(room) == 1))
	    pthread_cond_signal(&room->wolves.condit);
	  else if(room->cats.wait > 0 && cat_can_enter(room) == 1)
	    pthread_cond_signal(&room->cats.condit);	
	  else
	    rest_may_enter(room);
	}
	pthread_mutex_unlock(&room->lock);
}

void cat_enter(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);	
	while(room->dogs.n > 0 || room->birds.n > 0 || room->wolves.n > 0 || room->mice.n > 0)
	{
	  room->cats.wait++;
	  pthread_cond_wait(&room->cats.condit, &room->lock);
	  room->cats.wait--;
	}
	if(room->cats.wait > 0)
	{
	  room->cats.wakeup += room->cats.wait;
	  pthread_cond_broadcast(&room->cats.condit);
	}
	room->cats.n++;
	room->cats.total++;
	pthread_mutex_unlock(&room->lock);
}

void cat_exit(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);
	room->cats.n--;
	if(room->cats.n == 0)
	{
	  // You know a wolf can enter since the last cat left, see
	  // if any are waiting
	  if(room->wolves.wait>0)
	    pthread_cond_signal(&room->wolves.condit);
	  else if(room->cats.wait>0)
	    pthread_cond_signal(&room->wolves.condit);
	  else
	    rest_may_enter(room);
	}
	pthread_mutex_unlock(&room->lock);
}

void dog_enter(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);	
	while(room->cats.n > 0 || room->wolves.n > 0 || room-> mice.n > 0)
	{	
	  room->dogs.wait++;
	  pthread_cond_wait(&room->dogs.condit, &room->lock);
	  room->dogs.wait--;
	}
	if(room->dogs.wait > 0)
	{
	  room->dogs.wakeup += room->dogs.wait;
	  pthread_cond_broadcast(&room->dogs.condit);
	}
	room->dogs.n++;
	room->dogs.total++;
	pthread_mutex_unlock(&room->lock);
}

void dog_exit(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);
	room->dogs.n--;
	if(room->dogs.n == 0)
	{
	  if(room->wolves.wait > 0 && wolf_can_enter(room) == 1)
	    pthread_cond_signal(&room->wolves.condit);
	  else if(room->cats.wait > 0 && cat_can_enter(room) == 1)
	    pthread_cond_signal(&room->cats.condit);	
	  else
	    rest_may_enter(room);
	}
	pthread_mutex_unlock(&room->lock);
}

void mouse_enter(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);	
	while(room->cats.n > 0 || room->dogs.n > 0 || room->wolves.n > 0)
	{	
	  room->mice.wait++;
	  pthread_cond_wait(&room->mice.condit, &room->lock);
	  room->mice.wait--;
	}
	if(room->mice.wait > 0)
	{
	  room->mice.wakeup += room->mice.wait;
	  pthread_cond_broadcast(&room->mice.condit);
	}
	room->mice.n++;
	room->mice.total++;
	pthread_mutex_unlock(&room->lock);
}

void mouse_exit(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);
	room->mice.n--;
	if(room->mice.n == 0)
	{
	  if(room->wolves.wait > 0 && wolf_can_enter(room) == 1)
	    pthread_cond_signal(&room->wolves.condit);
	  else if(room->cats.wait > 0 && cat_can_enter(room) == 1)
	    pthread_cond_signal(&room->cats.condit); 
	  else
	    rest_may_enter(room);
	}
	pthread_mutex_unlock(&room->lock);
}

void wolf_enter(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);	
	while(room->cats.n > 0 || room->dogs.n > 0 || room->birds.n > 0 || room->wolves.n > 0 || room->mice.n > 0)
	{	
	  room->wolves.wait++;
	  pthread_cond_wait(&room->wolves.condit, &room->lock);
	  room->wolves.wait--;
	}
	if(room->wolves.wait > 0)
	{
	  room->wolves.wakeup += room->wolves.wait;
	}
	room->wolves.n++;
	room->wolves.total++;
	pthread_mutex_unlock(&room->lock);
}

void wolf_exit(struct playroom *room)
{
	pthread_mutex_lock(&room->lock);
	room->wolves.n--;
	if(room->cats.wait > 0)
	  pthread_cond_signal(&room->cats.condit);
	else
	  rest_may_enter(room);
	pthread_mutex_unlock(&room->lock);
}

// Output functions
void playroom_print(struct playroom *room)
{
	// Use this so we get a consistent snapshot
	pthread_mutex_lock(&room->lock);
	printf("play: %2dc %2dd %2db %2dm %2dw \t wait: %2dc %2dd %2db %2dm %2dw \t wakeups: %2dc %2dd %2db %2dm %2dw \t total: %2dc %2dd %2db %2dm %2dw \n",
			room->cats.n, room->dogs.n, room->birds.n, room->mice.n, room->wolves.n,
			room->cats.wait, room->dogs.wait, room->birds.wait, room->mice.wait, room->wolves.wait,
			room->cats.wakeup, room->dogs.wakeup, room->birds.wakeup, room->mice.wakeup, room->wolves.wakeup,
			room->cats.total, room->dogs.total, room->birds.total, room->mice.total, room->wolves.wakeup);
	pthread_mutex_unlock(&room->lock);
}

void playroom_visual(struct playroom *room)
{
	int i;

	// Print out a one-line "visual" view of the playroom state
	pthread_mutex_lock(&room->lock);
	for (i = NUM_CATS; i > room->cats.wait; i--)
		printf(" ");
	for (; i > 0; i--)
		printf("c");
	printf("|");
	for (i = 0; i < room->cats.n; i++)
		printf("c");
	for (; i < NUM_CATS; i++)
		printf(" ");

	for (i = NUM_DOGS; i > room->dogs.n; i--)
		printf(" ");
	for (; i > 0; i--)
		printf("d");
	printf("|");
	for (i = 0; i < room->dogs.wait; i++)
		printf("d");
	for (; i < NUM_DOGS; i++)
		printf(" ");

	printf("\n");
	pthread_mutex_unlock(&room->lock);
}
